package com.siddu.auth.controller;

import com.siddu.auth.dto.Requests.RoleRequest;
import com.siddu.auth.dto.Requests.StatusUpdateRequest;
import com.siddu.auth.dto.Response.RolesResponse;
import com.siddu.auth.dto.Response.StatusUpdateResponse;
import com.siddu.auth.dto.Response.UserStatusResponse;
import com.siddu.auth.service.UserAccessManagementService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;

@RestController
public class UserAccessController {
    private final UserAccessManagementService userAccessManagementService;
    @Autowired
    public UserAccessController(UserAccessManagementService userAccessManagementService) {
        this.userAccessManagementService = userAccessManagementService;
    }


    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @GetMapping("/admin/auth/users")
    public ResponseEntity<Page<UserStatusResponse>> getUsers(@RequestParam(defaultValue = "0") int page,@RequestParam(defaultValue = "15") int size) {
        return  ResponseEntity.ok(userAccessManagementService.getUsers(page,size));

    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/auth/users/roles/assign")
    public ResponseEntity<RolesResponse> assignRole(@Valid @RequestBody RoleRequest roleAssignRequest) {
        return ResponseEntity.ok(userAccessManagementService.assignRole(roleAssignRequest));

    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/auth/users")
    public ResponseEntity<RolesResponse> revokeRole(@Valid @RequestBody RoleRequest roleRevokeRequest) {
        return ResponseEntity.ok(userAccessManagementService.revokeRole(roleRevokeRequest));

    }


    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @PatchMapping("/admin/auth/users/status")
     public ResponseEntity<StatusUpdateResponse>  updateStatus(@Valid @RequestBody StatusUpdateRequest request){
        return ResponseEntity.ok(userAccessManagementService.updateStatus(request));
    }


}
