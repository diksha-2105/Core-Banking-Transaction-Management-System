package com.siddu.accounts.Controller;

import com.siddu.accounts.Dto.Requests.*;
import com.siddu.accounts.Dto.Responses.*;
import com.siddu.accounts.Utils.SecurityUtils;
import com.siddu.accounts.services.BankAccountService;
import com.siddu.accounts.services.ProfilemanagementService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
public class AccountController {


    private final BankAccountService bankAccountService;
    private final ProfilemanagementService profilemanagementService;
    @Autowired
    public AccountController(BankAccountService bankAccountService,
                             ProfilemanagementService profilemanagementService
    ) {
        this.bankAccountService = bankAccountService;
        this.profilemanagementService = profilemanagementService;
    }

    @PostMapping("profile/create-bank-Profile")
    public ResponseEntity<ProfileResponse> createbankprofile(@Valid @RequestBody CreateProfile request) {
        return ResponseEntity.ok(profilemanagementService.createProfile(request));
    }
    @PutMapping("/profile/address")
    public  ResponseEntity<ApiResponse<ProfileResponse>> updateAddress(@Valid @RequestBody AddressUpdateRequest request){
        return ResponseEntity.ok(profilemanagementService.updateAddress(request));
    }
    @PostMapping("/profile/name")
    public ResponseEntity<SuccessResponse> updateProfileName(@Valid @RequestBody UpdateProfileNameRequest request){
        return ResponseEntity.ok(profilemanagementService.updateProfilename(request.name()));
    }
    @GetMapping("profile/me")
    public ResponseEntity<ProfileResponse> getProfile() {
        UUID userId= SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(profilemanagementService.getProfileDetails(userId));
    }

    @PostMapping("accounts/create-bank-account")
    public ResponseEntity<ApiResponse<BankAccountResponse>> createBankAccount(@Valid @RequestBody CreateBankAccountRequest Request) {
        return ResponseEntity.ok(bankAccountService.createBankAccount(Request));

    }


    @GetMapping("/accounts/me")
    public ResponseEntity<AccountsResponse> getAccountProfile() {

        UUID userId= SecurityUtils.getCurrentUserId();
        return ResponseEntity.ok(bankAccountService.getAccountDetails(userId));
    }


    @PostMapping("/accounts/check-balance")
    public ResponseEntity<CheckBalanceResponse> getAccountBalance(@Valid @RequestBody CheckBalanceRequest request)  {
        return ResponseEntity.ok(bankAccountService.checkaccountbalance(request));

    }



}
